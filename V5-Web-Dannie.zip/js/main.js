// ===============================
// SCRIPT SITIO DANNIE
// ===============================

document.addEventListener('DOMContentLoaded', function () {
    const pagina = document.body.id;

    // FADE NAV
    const dropdown = document.querySelector('.nav-item.dropdown');
    const dropdownToggle = dropdown?.querySelector('.nav-link.dropdown-toggle');

    if (dropdown && dropdownToggle) {
        dropdown.addEventListener('mouseleave', () => {
            const bsDropdown = bootstrap.Dropdown.getInstance(dropdownToggle);
            if (bsDropdown) bsDropdown.hide();
        });

        dropdownToggle.addEventListener('mouseenter', () => {
            const bsDropdown = bootstrap.Dropdown.getOrCreateInstance(dropdownToggle);
            bsDropdown.show();
        });
    }

    //SUBMENÚ SERVICIOS
    const serviciosLink = document.getElementById('serviciosLink');
    const dropdownMenu = serviciosLink?.nextElementSibling;

    if (serviciosLink && dropdownMenu) {
        const isMobile = window.innerWidth < 992;

        if (isMobile) {
            // En móvil: clic abre/cierra submenú
            serviciosLink.addEventListener('click', function (e) {
                e.preventDefault();
                const alreadyShown = dropdownMenu.classList.contains('show');
                document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
                    menu.classList.remove('show');
                });
                if (!alreadyShown) {
                    dropdownMenu.classList.add('show');
                }
            });

            // Cierra submenú si tocas fuera
            document.addEventListener('click', function (e) {
                if (!e.target.closest('.dropdown')) {
                    document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
                        menu.classList.remove('show');
                    });
                }
            });
        } else {
            // En escritorio: clic te lleva a #servicios
            serviciosLink.addEventListener('click', function (e) {
                e.preventDefault();
                window.location.href = 'index.html#servicios';
            });

            // Hover muestra submenú
            const dropdown = serviciosLink.closest('.dropdown');
            dropdown.addEventListener('mouseenter', () => {
                dropdownMenu.classList.add('show');
            });
            dropdown.addEventListener('mouseleave', () => {
                dropdownMenu.classList.remove('show');
            });
        }
    }

    // ANIMACIÓN CON SCROLL PARA .ANIMAR-SCROLL
    const elementosAnimados = document.querySelectorAll('.animar-scroll');

    if (elementosAnimados.length > 0) {
        function mostrarScrollAnimado() {
            elementosAnimados.forEach((el, index) => {
                const rect = el.getBoundingClientRect();
                if (rect.top < window.innerHeight - 100 && rect.bottom > 100) {
                    el.style.setProperty('--delay', `${index * 0.2}s`);
                    el.classList.add('visible');
                } else {
                    el.classList.remove('visible');
                }
            });
        }
        window.addEventListener("scroll", mostrarScrollAnimado);
        mostrarScrollAnimado();
    }

    // Solo para página de INICIO
    if (pagina === 'pagina-inicio') {
        // Logo fade-out al cargar
        const intro = document.getElementById('intro-logo');
        if (intro) {
            setTimeout(() => {
                intro.classList.add('fade-out');
            }, 2000);
        }

        // Movimiento img-cambio DETRÁS DE ESCENA
        const images = document.querySelectorAll('.img-cambio img');
        let current = 0;
        if (images.length > 0) {
            setInterval(() => {
                images[current].classList.remove('active');
                current = (current + 1) % images.length;
                images[current].classList.add('active');
            }, 2000);
        }
    }

    // Solo para página de ILUSTRACIÓN
    if (pagina === 'pagina-ilustracion') {
        const triggers = document.querySelectorAll('.lightbox-trigger');
        const lightbox = document.getElementById('lightbox');
        const lightboxImg = document.getElementById('lightbox-img');
        const closeBtn = document.getElementById('lightbox-close');

        if (lightbox && lightboxImg && closeBtn && triggers.length > 0) {
            triggers.forEach(img => {
                img.addEventListener('click', () => {
                    lightboxImg.src = img.src;
                    lightbox.classList.remove('hidden');
                });
            });

            closeBtn.addEventListener('click', () => {
                lightbox.classList.add('hidden');
                lightboxImg.src = '';
            });

            lightbox.addEventListener('click', (e) => {
                if (e.target === lightbox) {
                    lightbox.classList.add('hidden');
                    lightboxImg.src = '';
                }
            });
        }
    }

     // Cierra el offcanvas al hacer clic en cualquier enlace excepto Servicios
    const links = document.querySelectorAll('.offcanvas-body a');
    const offcanvasElement = document.getElementById('offcanvasNavbar');

    if (offcanvasElement && links.length > 0) {
        const bsOffcanvas = bootstrap.Offcanvas.getOrCreateInstance(offcanvasElement);

        links.forEach(link => {
            // No cerrar si es el link de "Servicios"
            if (link.id !== 'serviciosLink') {
                link.addEventListener('click', () => {
                    bsOffcanvas.hide();
                });
            }
        });
    }
});

function scrollToMenu() {
    const isMobile = window.innerWidth <= 991;
    const targetId = isMobile ? 'menu-fotografia-movil' : 'menu-fotografia-escritorio';
    const target = document.getElementById(targetId);

    if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
    }
}